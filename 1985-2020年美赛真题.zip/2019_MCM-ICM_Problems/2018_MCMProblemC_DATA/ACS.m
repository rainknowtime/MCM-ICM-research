root_10 = 'ACS_10_5YR_DP02';
ACS_path = [root_10, '/', root_10, '_metadata.csv'];
[~, text_10] = xlsread(ACS_path);

root_11 = 'ACS_11_5YR_DP02';
ACS_path = [root_11, '/', root_11, '_metadata.csv'];
[~, text_11] = xlsread(ACS_path);

root_12 = 'ACS_12_5YR_DP02';
ACS_path = [root_12, '/', root_12, '_metadata.csv'];
[~, text_12] = xlsread(ACS_path);

root_13 = 'ACS_13_5YR_DP02';
ACS_path = [root_13, '/', root_13, '_metadata.csv'];
[~, text_13] = xlsread(ACS_path);

root_14 = 'ACS_14_5YR_DP02';
ACS_path = [root_14, '/', root_14, '_metadata.csv'];
[~, text_14] = xlsread(ACS_path);

root_15 = 'ACS_15_5YR_DP02';
ACS_path = [root_15, '/', root_15, '_metadata.csv'];
[~, text_15] = xlsread(ACS_path);

root_16 = 'ACS_11_5YR_DP02';
ACS_path = [root_16, '/', root_16, '_metadata.csv'];
[~, text_16] = xlsread(ACS_path);