clear all;
load struct_data
load county_data